<?php
define('DBHOST', 'localhost');
define('DBUSER', 'root');
define('DBNAME', 'sport_registration');


$db_con = mysqli_connect(DBHOST, DBUSER, '', DBNAME);
