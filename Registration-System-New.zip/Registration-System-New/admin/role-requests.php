<?php
require_once 'db_con.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user_login'])) {
    header('Location: login.php');
    exit;
}
$__u = $_SESSION['user_login'];
$__res = mysqli_query($db_con, "SELECT `role` FROM `users` WHERE `username` = '$__u' LIMIT 1");
$__row = $__res ? mysqli_fetch_assoc($__res) : null;
if (!$__row || $__row['role'] !== 'admin') {
    header('Location: ../profile.php');
    exit;
}
?>

<h1 class="text-primary"><i class="fas fa-user-check"></i> Role Requests</h1>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item" aria-current="page"><a href="index.php">Dashboard</a></li>
        <li class="breadcrumb-item active" aria-current="page">Role Requests</li>
    </ol>
</nav>

<table class="table table-striped table-hover table-bordered" id="data">
    <thead class="thead-dark">
    <tr>
        <th>Full Name</th>
        <th>Email</th>
        <th>Username</th>
        <th>Requested Role</th>
        <th>Status</th>
        <th>Action</th>
    </tr>
    </thead>
    <tbody>
    <?php
    $result = mysqli_query($db_con, "SELECT * FROM `users` WHERE `status` = 'pending'");
    while ($row = mysqli_fetch_assoc($result)) {
        ?>
        <tr>
            <td><?php echo htmlspecialchars($row['full_name']); ?></td>
            <td><?php echo htmlspecialchars($row['email']); ?></td>
            <td><?php echo htmlspecialchars($row['username']); ?></td>
            <td><?php echo htmlspecialchars($row['role']); ?></td>
            <td><?php echo htmlspecialchars($row['status']); ?></td>
            <td>
                <a href="index.php?page=role-requests&approve=<?php echo $row['id']; ?>" class="btn btn-success">Approve</a>
                <a href="index.php?page=role-requests&decline=<?php echo $row['id']; ?>" class="btn btn-danger">Decline</a>
            </td>
        </tr>
    <?php } ?>
    </tbody>
</table>
