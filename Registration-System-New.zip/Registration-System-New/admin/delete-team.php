<?php
require_once 'db_con.php';
if (session_status() === PHP_SESSION_NONE) { session_start(); }
if (!isset($_SESSION['user_login'])) { header('Location: login.php'); exit; }
$__u = $_SESSION['user_login'];
$__res = mysqli_query($db_con, "SELECT `role` FROM `users` WHERE `username` = '$__u' LIMIT 1");
$__row = $__res ? mysqli_fetch_assoc($__res) : null;
if (!$__row || $__row['role'] !== 'admin') { header('Location: ../profile.php'); exit; }
<?php
$id = base64_decode($_GET['id']);
if(mysqli_query($db_con,"DELETE FROM `teams` WHERE `id` = '$id'")){
	header('Location: index.php?page=all-teams&delete=success');
}else{
	header('Location: index.php?page=all-teams&delete=error');
}
?>